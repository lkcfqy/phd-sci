# Anonymous reproducibility bundle

This bundle accompanies a double-blind submission on healthy-only cross-dataset PMSM
fault detection. Raw datasets are excluded. Download and verify the public datasets by
following `docs/data_sources.yaml`, then run the scripts described in the project
protocol. The bundle contains analysis code, tests, frozen protocols, and selected
derived results. It intentionally contains no author names, affiliations, Git history,
or local absolute paths.

## Environment and smoke test

```text
python -m venv .venv
python -m pip install -U pip
python -m pip install -e ".[dev]"
python -m pytest
ruff check .
```

The public raw files are not redistributed. Primary dataset identifiers, licenses,
download locations, and expected hashes are in `docs/data_sources.yaml`; the locked
split and one-time external-reveal rules are in `docs/research_protocol.md`,
`docs/external_validation_protocol.md`, `docs/fault_reveal_log.md`,
`docs/secondary_transient_validation_protocol.md`, and
`docs/secondary_transient_reveal_log.md`. Selected frozen outputs are included under
`results/`. Every archived file covered by the internal manifest can be checked against
`MANIFEST_SHA256.json`.
